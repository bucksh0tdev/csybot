const Discord = require("discord.js");
const CSYBOT = require("discord-v13-interaction");
const config = require("../config.json");
exports.run = async (client, interaction, options) => {
const csybot = new CSYBOT(config.secretKey, client, interaction);

return csybot.send({ content: "Hello" });

};

exports.help = {
  name: "test",
  description: "Testing Command",
  options: null
};