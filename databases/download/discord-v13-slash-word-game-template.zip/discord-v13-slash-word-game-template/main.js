const Discord = require("discord.js");
const fs = require("fs");
const request = require('request');
const client = new Discord.Client({ partials: ["CHANNEL"], intents: [Discord.Intents.FLAGS.GUILDS, Discord.Intents.FLAGS.GUILD_MESSAGES, Discord.Intents.FLAGS.GUILD_MEMBERS, Discord.Intents.FLAGS.GUILD_VOICE_STATES, Discord.Intents.FLAGS.DIRECT_MESSAGES] });
const config = require("./config");
const db = config.db;
const CSYBOT = require("discord-v13-interaction");

const csyexpress = require("express");
   const csyapp = csyexpress();
   const csyport = process.env.PORT || 3000;
   csyapp.listen(csyport, () => console.log(`${csyport}!`));
   console.log("Uptime Başlatıldı")
   csyapp.get("/", (request, response) => {
     response.send('Uptimed');
   });

client.on("ready", () => {
  client.commands = new Discord.Collection();
  const commandFiles_en = fs.readdirSync(__dirname + "/./commands").filter(file => file.endsWith('.js'));

  for (const file of commandFiles_en) {
    const command = require(`./commands/${file}`);
    client.commands.set(command.help.name, file);
  }

  client.user.setActivity("Word Bot", {
    url: "https://www.twitch.tv/csycraft",
    type: "STREAMING"
  });

  console.log("Bot is ready, Name:", client.user.tag)
})

client.on("messageCreate", async(message) => {
  if(!message || !message.author || !message.guild || message.author.id != config.owner) return;
  if(message.content == "s!reload") {
    const csybot = new CSYBOT(config.secretKey, client);
    var msg;
    await message.channel.send("Reloading (/) Commands").then(msgs => msg = msgs);

    client.commands = new Discord.Collection();

    var commands = [];
    let commandfiles = fs.readdirSync(__dirname + "/commands").filter(file => file.endsWith('.js'));

    for (const file of commandfiles) {
        let command = require(`./commands/${file}`);
        client.commands.set(command.help.name, file);
        commands.push(command.help);
    }

    await csybot.reloadcommand(commands);
    msg.edit("Reloaded (/) Commands. Bot Exited!");
  }
});


client.ws.on("INTERACTION_CREATE", async(interaction) => {
  const globalfun = require("./functions/index");
  const fun = new globalfun(client, interaction);
  const csybot = new CSYBOT(config.secretKey, client, interaction);

  if(interaction.data.custom_id) return;

  if(!client.commands) return;
  if (!client.commands.has(interaction.data.name)) {
    client.api.interactions(interaction.id, interaction.token).callback.post({
      data: {
        type: 4,
        data: {
          content: `Sorry, This Command Has Been Deleted, Or Under Maintenance!`,
          ephemeral: false
        }
      }
    });
    return;
  }
  try {
    let mycommandfilename = client.commands.get(interaction.data.name);
    let mycommand = require(`./commands/${mycommandfilename}`);

    mycommand.run(client, interaction, interaction.data.options)//.catch(err => err + "1");

  } catch (error) {
    console.log(error);
    client.api.interactions(interaction.id, interaction.token).callback.post({
      data: {
        type: 4,
        data: {
          content: `Sorry, I Think An Error Occurred!`,
          ephemeral: false
        }
      }
    })
  };
  
});

let waiting;
client.on("messageCreate", async(message) => {
if(!message || !message.guild || message.author.bot || !message.channel || (message.content).startsWith("!")) return;
  let control = db.get(`wordgame_${message.guild.id}`);
  if(!control || message.channel.id != control) return;
  let lasts = db.get(`wordgamelast_${message.guild.id}`);
  
  let letter = message.content.toLowerCase().replace('Ğ','ğ').replace('Ü','ü').replace('Ş','ş').replace('I','ı').replace('İ','i').replace('Ö','ö').replace('Ç','ç');
  let reg = /[a-zA-Zqwertyuıoöjpğüş]/g;
  
  if(!lasts) {
    if (!letter.match(reg)) {
       message.delete().catch(x => x + "err");
       return message.channel.send("Contains invalid characters. Please use only Turkish characters and letters.").then(msg => setTimeout(() => msg.delete(), 3000)).catch(err => err + "1");
    } else if (letter.length <= 2) {
       message.delete().catch(x => x + "err");
       return message.channel.send("Word Too Short").then(msg => setTimeout(() => msg.delete(), 3000)).catch(err => err + "1");
    }
    
    let link = encodeURI("https://sozluk.gov.tr/gts?ara=" + letter); 
    await request.post(link, { json: { key: 'value' } }, async(error, res, body) => {
      if (error) return message.channel.send("Error 203");
      if(body.error) return message.channel.send("The word was not found in the Turkish Language Institution!").then(msg => setTimeout(() => msg.delete(), 3000)).catch(err => err + "1");
      let lasts2 = db.get(`wordgamelast_${message.guild.id}`);
      if(lasts2) {
        message.delete().catch(err => err + "1");
        return;
      } 
    db.set(`wordgamelast_${message.guild.id}`, [{ "user": client.user.id, "message": `${letter}` }]);
    message.react("✅");
    });
    return
  }
  
  let lastletter = letter.charAt(0);
  let last = lasts[lasts.length - 1];

  let backlast = last.message.charAt(last.message.length - 1)
  
  if(message.author.id == last.user) {
    message.delete().catch(x => x + "err");
    return message.channel.send("You Can't Play This Game Alone").then(msg => setTimeout(() => msg.delete(), 3000)).catch(err => err + "1");
  } else if (!letter.match(reg)) {
    message.delete().catch(x => x + "err");
    return message.channel.send("Contains invalid characters. Please use only Turkish characters and letters.").then(msg => setTimeout(() => msg.delete(), 3000)).catch(err => err + "1");
  } else if (lastletter != backlast) {
    message.delete().catch(x => x + "err");
    return message.channel.send("Must Begin With Last Letter (**" + backlast + "**).").then(msg => setTimeout(() => msg.delete(), 3000)).catch(err => err + "1");
  } else if (lasts.find(x => x.message == letter)) {
    message.delete().catch(x => x + "err");
    return message.channel.send("This Word Has Been Used Before!").then(msg => setTimeout(() => msg.delete(), 3000)).catch(err => err + "1");
  } else if (letter.length <= 2) {
    message.delete().catch(x => x + "err");
    return message.channel.send("Word Too Short").then(msg => setTimeout(() => msg.delete(), 3000)).catch(err => err + "1");
  }
  
  let link = encodeURI("https://sozluk.gov.tr/gts?ara=" + letter); 
    await request.post(link, { json: { key: 'value' } }, async(error, res, body) => {
      if (error) return message.channel.send("Error 204");
      if(body.error) return message.channel.send("The word was not found in the Turkish Language Institution!").then(msg => setTimeout(() => msg.delete(), 3000)).catch(err => err + "1");
      if(lasts.find(x => x.message == letter)) {
        message.channel.send("This Word Has Been Used Before!").then(msg => setTimeout(() => msg.delete(), 3000)).catch(err => err + "1"); 
        message.delete().catch(err => err + "err");
        return;
      }
      message.react("✅");
      if(lastletter == "ğ") {
        db.delete(`wordgamelast_${message.guild.id}`);
        await message.channel.send({ embeds: [config.win] })
        return;
      }
      
      lasts.push({ "user": message.author.id, "message": message.content });
      db.set(`wordgamelast_${message.guild.id}`, lasts);
    })
  
  
});

client.login(config.token).catch(err => err + console.log("Token Invald Please Renew!"));