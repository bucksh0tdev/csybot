const dbs = require("quick.db");

module.exports = {
    // Config Not Editable
    "secretKey": "SECRET",
    "token": "TOKEN",
    "owner": "OWNER",
    db: dbs,
    win: {
    	color: 0x0099ff,
    	title: 'Kelime Oyunu Başlatıldı',
    	description: `İlk Kelimeyi Sen Yaz!`,
    	footer: {
      	text: this.footer,
    	}
     },

    // Config Editable
    "footer": "Editable (./config.js:19)",

}