const Discord = require("discord.js");
const CSYBOT = require("discord-v13-interaction");
const config = require("../config");
const db = config.db;
const globalfun = require("../functions/index");
exports.run = async (client, interaction, options) => {
const csybot = new CSYBOT(config.secretKey, client, interaction);
const fun = new globalfun(client, interaction);

if(interaction.member.user.id != config.owner) return csybot.send("Only Owner Command");

let set = fun.options("set", true);
let reset = fun.options("reset", true);
let guild = client.guilds.cache.get(interaction.guild_id);
if(!guild) return csybot.send("Error 202!");
  
if(set) {
  let channel = fun.options("channel", true, "set");
  let getchannel = guild.channels.cache.get(channel);
  if(!getchannel) return csybot.send("Channel Not Found!");
  
  let embed = config.win
  
  getchannel.send({ embeds: [embed] }).catch(err => err + "1");
  
  db.set(`wordgame_${interaction.guild_id}`, getchannel.id);
  
  return csybot.send("Success, Channel <#" + getchannel.id + "> Set!");
  
} else if (!set && reset) {
  let control = db.get(`wordgame_${interaction.guild_id}`);
  if(!control) return csybot.send("Word Game Not Found!");
  
  db.delete(`wordgame_${interaction.guild_id}`);
  db.delete(`wordgamelast_${interaction.guild_id}`);
  
  return csybot.send("Success, Word Game Channel Reset")
  
  
}

  
  

};

exports.help = {
  name: "word-game",
  description: "Word Game",
  options: [{
      type: 1,
      name: "set",
      description: "Set Word Game",
      options: [{
        type: 7,
        name: "channel",
        description: "Set Game Play Channel",
        required: true
      }]
  },
  {
    type: 1,
    name: "reset",
    description: "Word Game Channel Reset",
    options: null
  }]
};