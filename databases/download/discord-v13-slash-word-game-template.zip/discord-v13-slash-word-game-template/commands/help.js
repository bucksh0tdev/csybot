const Discord = require("discord.js");
const CSYBOT = require("discord-v13-interaction");
const config = require("../config");
const db = config.db;
const globalfun = require("../functions/index");
exports.run = async (client, interaction, options) => {
const csybot = new CSYBOT(config.secretKey, client, interaction);
const fun = new globalfun(client, interaction);

const embed = {
	color: 0x0099ff,
	author: {
		name: 'Komutlar',
	},
	fields: [{
			name: '/kelime-turetmece',
			value: 'Kelime Türtmece Oyunu Ayarla',
		}
    ],
	footer: {
		text: config.footer,
	},
};

return csybot.send({ embeds: [embed] });

};

exports.help = {
  name: "yardım",
  description: "Yardım komutu",
  options: []
};