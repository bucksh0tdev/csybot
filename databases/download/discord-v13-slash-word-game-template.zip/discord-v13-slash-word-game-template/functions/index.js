'use strict';
const Discord = require("discord.js");
const config = require("../config");
const db = config.db;

module.exports = function (client, interaction = null) {

  this.options = function (name, sub = false, ultrasub = false) {

    if(!interaction.data.options) return false;

    if(sub) {
      if(ultrasub) {
        let getoption = interaction.data.options.filter(option => option.name === ultrasub);
        if(!getoption || !getoption[0] || !getoption[0].options) return false;
        let getoption2 = getoption[0].options.filter(option => option.name === name);
        if(!getoption2 || !getoption2[0]) return false;
        return getoption2[0].value;
      } else {
        let getoption = interaction.data.options.filter(option => option.name === name);
        if(!getoption || !getoption[0]) return false;
        return true;
      }
    } else {
      let getoption = interaction.data.options.filter(option => option.name === name);
      if(!getoption || !getoption[0]) return false;
      return getoption[0].value;
    }

  }


};