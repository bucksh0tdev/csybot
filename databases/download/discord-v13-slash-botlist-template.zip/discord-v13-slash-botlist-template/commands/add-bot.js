const Discord = require("discord.js");
const CSYBOT = require("discord-v13-interaction");
const config = require("../config");
const db = config.db;
const globalfun = require("../functions/index");
exports.run = async (client, interaction, options) => {
const csybot = new CSYBOT(config.secretKey, client, interaction);
const fun = new globalfun(client, interaction);

let botid = interaction.data.options[0].value;
if(!botid) return csybot.send("Null, Bot ID");

let control = await db.fetch(`bots_${botid}`);
if(control) return csybot.send("Already, Added Bot!");

if(interaction.channel_id != config.addbotchannel) return csybot.send(`Please Only Use Channel <#${config.addbotchannel}>`, true);

let usercontrol = await fun.userget(botid);
  
console.log(usercontrol)
  
if(!botid || !usercontrol || !usercontrol.id || usercontrol.bot != true) return csybot.send("Bot Not Found.");
let guild = await client.guilds.cache.get(interaction.guild_id);
let botcontrol = await fun.getmember(botid);
if(botcontrol) return csybot.send("The bot exists on the server.");

let channel = await guild.channels.cache.get(config.logchannel);
let channel2 = await guild.channels.cache.get(config.adminchannel);
if(!channel || !channel2) return csybot.send("Command Channels Deleted. Please Contact Server Administrator!");

let info = new Discord.MessageEmbed()
.setTitle(`**New Bot Added to Queue**`, true)
.setDescription(`Bot Owner Is: <@${interaction.member.user.id}>`)
.addFields(
    { name: 'Username:', value: `\`\`\`${fun.filter(String(usercontrol.username) + "#" + String(usercontrol.discriminator))}\`\`\``, inline: true },
    { name: 'ID:', value: `\`\`\`${fun.filter(usercontrol.id)}\`\`\``, inline: true }
)
.setFooter(`${config.footer}`)
.setColor('BLUE');
let msg = await channel.send({ embeds: [info] });

const row = new Discord.MessageActionRow()
.addComponents(
  new Discord.MessageButton()
    .setCustomId(`confirm_${usercontrol.id}`)
    .setLabel('Confirm')
    .setStyle(3)
)
.addComponents(
  new Discord.MessageButton()
    .setCustomId(`decline_${usercontrol.id}`)
    .setLabel('Decline')
    .setStyle(4)
)
.addComponents(
  new Discord.MessageButton()
    .setLabel('Invite')
    .setStyle(5)
    .setURL(`https://discord.com/oauth2/authorize?client_id=${usercontrol.id}&permissions=0&scope=bot&guild_id=${interaction.guild_id}`)
);

let info2 = new Discord.MessageEmbed()
.setTitle(`**New Bot Added to Queue**`, true)
.setDescription(`Bot Owner Is: <@${interaction.member.user.id}>`)
.addFields(
    { name: 'Username:', value: `\`\`\`${fun.filter(String(usercontrol.username) + "#" + String(usercontrol.discriminator))}\`\`\``, inline: true },
    { name: 'ID:', value: `\`\`\`${fun.filter(usercontrol.id)}\`\`\``, inline: true }
)
.setFooter(`${config.footer}`)
.setColor('BLUE');

let admin = await channel2.send({ content: `<@&${config.adminrole}>, New Bot Request`, embeds: [info2], components: [row] });
  
let json = {
  edit: msg.id,
  ownerid: interaction.member.user.id,
  botid: usercontrol.id,
  stat: false
};

db.set(`bots_${usercontrol.id}`, `${JSON.stringify(json)}`);
return csybot.send("Added to List");

};

exports.help = {
  name: "bot-ekle",
  description: "Botunu Ekle",
  options: [{
    type: 3,
    name: "bot-id",
    description: "Botun Idsi",
    required: true
  }]
};