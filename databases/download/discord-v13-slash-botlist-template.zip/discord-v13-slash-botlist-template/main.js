const Discord = require("discord.js");
const fs = require("fs");
const client = new Discord.Client({ partials: ["CHANNEL"], intents: [Discord.Intents.FLAGS.GUILDS, Discord.Intents.FLAGS.GUILD_MESSAGES, Discord.Intents.FLAGS.GUILD_MEMBERS, Discord.Intents.FLAGS.GUILD_VOICE_STATES, Discord.Intents.FLAGS.DIRECT_MESSAGES] });
const config = require("./config");
const db = config.db;
const CSYBOT = require("discord-v13-interaction");

client.on("ready", () => {
  client.commands = new Discord.Collection();
  const commandFiles_en = fs.readdirSync(__dirname + "/./commands").filter(file => file.endsWith('.js'));

  for (const file of commandFiles_en) {
    const command = require(`./commands/${file}`);
    client.commands.set(command.help.name, file);
  }

  client.user.setActivity("BotList Altyapısı", {
    url: "https://www.twitch.tv/csycraft",
    type: "STREAMING"
  });

  console.log("Bot is ready, Name:", client.user.tag)
})

client.on("messageCreate", async(message) => {
  if(!message || !message.author || !message.guild || message.author.id != config.owner) return;
  if(message.content == "s!reload") {
    const csybot = new CSYBOT(config.secretKey, client);
    var msg;
    await message.channel.send("Reloading (/) Commands").then(msgs => msg = msgs);

    client.commands = new Discord.Collection();

    var commands = [];
    let commandfiles = fs.readdirSync(__dirname + "/commands").filter(file => file.endsWith('.js'));

    for (const file of commandfiles) {
        let command = require(`./commands/${file}`);
        client.commands.set(command.help.name, file);
        commands.push(command.help);
    }

    await csybot.reloadcommand(commands);
    msg.edit("Reloaded (/) Commands. Bot Exited!");
  }
});


client.ws.on("INTERACTION_CREATE", async(interaction) => {
  const globalfun = require("./functions/index");
  const fun = new globalfun(client, interaction);
  const csybot = new CSYBOT(config.secretKey, client, interaction);

  if(interaction.data.custom_id) {


    let guild = await client.guilds.cache.get(interaction.guild_id);
    let user = await fun.getmember(interaction.member.user.id);
    if(!user.roles.cache.get(config.adminrole)) return csybot.send("Sorry, Adminastrator Required!")
   
    let datasplit = interaction.data.custom_id.split("_");
    let event = datasplit[0];
    let botid = datasplit[1];
    let datacontrol = await db.fetch(`bots_${botid}`);
    if(!datacontrol) {
      await db.delete(`bots_${botid}`);
      await csybot.send("Sorry, Bot Not Found!");
      return fun.deletemsg();
    }
    
    let parsed = JSON.parse(datacontrol);
    let userget = await fun.userget(botid);
    if(!userget) {
      await db.delete(`bots_${botid}`);
      await csybot.send("Sorry, Bot Not Found For Discord!");
      return fun.deletemsg();
    }
    let bot = await fun.getmember(botid);
    if(event == "confirm") {
      if(parsed.stat == true) {
        csybot.send("Sorry, Bot Already Confirmed!", true);
        return fun.deletemsg();
      }
      if(!bot) return csybot.send("Sorry, Bot not on server! Invite Please");
      parsed.stat = true;
      await csybot.data("set", "bots", `bot_${interaction.guild_id}_${botid}`, `${JSON.stringify(parsed)}`);
      fun.approve(parsed, userget);
      csybot.send("SUCCESS, Bot Confirmed!", true);
      return fun.deletemsg();
    } else if (event == "decline") {
      if(parsed.stat == true) {
        csybot.send("Sorry, Bot Already Confirmed!");
        return fun.deletemsg();
      }
      fun.deletemsg();
      await db.delete(`bots_${botid}`);
      fun.decline(parsed, userget);
      csybot.send("SUCCESS, Bot Declined!");
    }
    
  } else {
  if(!client.commands) return;
  if (!client.commands.has(interaction.data.name)) {
    client.api.interactions(interaction.id, interaction.token).callback.post({
      data: {
        type: 4,
        data: {
          content: `Sorry, This Command Has Been Deleted, Or Under Maintenance!`,
          ephemeral: false
        }
      }
    });
    return;
  }
  try {
    let mycommandfilename = client.commands.get(interaction.data.name);
    let mycommand = require(`./commands/${mycommandfilename}`);

    mycommand.run(client, interaction, interaction.data.options)//.catch(err => err + "1");

  } catch (error) {
    console.log(error);
    client.api.interactions(interaction.id, interaction.token).callback.post({
      data: {
        type: 4,
        data: {
          content: `Sorry, I Think An Error Occurred!`,
          ephemeral: false
        }
      }
    })
  };
  
  }
});

client.on("guildMemberRemove", async(member) => {
  if(member.user.bot) {
    db.delete(`bots_${member.id}`);
  }
});


client.login(config.token).catch(err => err + console.log("Token Invald Please Renew!"));