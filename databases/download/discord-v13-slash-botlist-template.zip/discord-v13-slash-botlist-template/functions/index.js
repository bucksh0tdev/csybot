'use strict';
const Discord = require("discord.js");
const axios = require("axios");
const config = require("../config");
const db = config.db;

module.exports = function (client, interaction = null) {

this.userget = async function(userid) {

  return new Promise(async(res, reject) => {

    axios.get(`https://discord.com/api/v8/users/${String(userid)}`, {
                        headers: {
                            'Authorization': `Bot ${config.token}`
                        }
                    }).then(x => {
                        res(x.data);
                    }).catch(err => {
          err + "1";
          res(null);
        });
  });

  
  
  
    }

this.getmember = async function(userid) {
  
        let guild = await client.guilds.cache.get(interaction.guild_id);
          
        return await guild.members.fetch(userid).then(x => {
                            return x;
                          }).catch(err => {
          err + "1";
          return null;
        });
          
}
  
        this.filter = function (text) {
            if (text.length > 100) return "[...]";
            var swears = ['"', "'", "*", "`", "$", "<", "_", "~", "\n", ">"];
            var result = text.replaceAll(swears, '')
            return result;
        }
  

this.deletemsg = async function() {
    let guild = await client.guilds.cache.get(interaction.guild_id);
    const channel = await guild.channels.cache.get(interaction.channel_id);
    if(!channel) return;
    const fetchedMsg = await channel.messages.fetch({ around: interaction.message.id, limit: 1 });
    let message = fetchedMsg.first();
    await message.delete();
  }

  this.approve = async function(parsed, userget) {
  
  let guild = await client.guilds.cache.get(interaction.guild_id);
  if(!guild) return;
  let channel = await guild.channels.cache.get(config.logchannel);
  if(!channel) return;
  const fetchedMsg = await channel.messages.fetch({ around: parsed.edit, limit: 1 });
  let message = fetchedMsg.first();

  let approved = new Discord.MessageEmbed()
  .setTitle(`**New Bot Approved to Queue**`, true)
  .setDescription(`Bot Owner Is: <@${parsed.ownerid}>`)
  .addFields(
      { name: 'Username:', value: `\`\`\`${this.filter(String(userget.username) + "#" + String(userget.discriminator))}\`\`\``, inline: true },
      { name: 'ID:', value: `\`\`\`${this.filter(userget.id)}\`\`\``, inline: true }
  )
  .setFooter(`${config.footer}`)
  .setColor('GREEN');
  message.edit({ embeds: [approved], content: `<@${parsed.ownerid}>, Approved Your Bot!` });
  this.ping(channel, parsed.ownerid);
}
  
  
this.decline = async function(parsed, userget) {
  let guild = await client.guilds.cache.get(interaction.guild_id);
  if(!guild) return;
  
  let channel = await guild.channels.cache.get(config.logchannel);
  const fetchedMsg = await channel.messages.fetch({ around: parsed.edit, limit: 1 });
  let message = fetchedMsg.first();

  let approved = new Discord.MessageEmbed()
  .setTitle(`**New Bot Declined to Queue**`, true)
  .setDescription(`Bot Owner Is: <@${parsed.ownerid}>`)
  .addFields(
      { name: 'Username:', value: `\`\`\`${this.filter(String(userget.username) + "#" + String(userget.discriminator))}\`\`\``, inline: true },
      { name: 'ID:', value: `\`\`\`${this.filter(userget.id)}\`\`\``, inline: true }
  )
  .setFooter(`${config.footer}`)
  .setColor('RED');
  message.edit({ embeds: [approved], content: `<@${parsed.ownerid}>, Declined Your Bot!` });
  this.ping(channel, parsed.ownerid);
}

this.ping = function(channel, userid) {
  
    channel.send(`<@${userid}>`).then(msg => {
      msg.delete();
    });
}

};