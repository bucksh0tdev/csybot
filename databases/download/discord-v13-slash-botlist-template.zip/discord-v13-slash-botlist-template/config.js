const { JsonDatabase } = require("wio.db");
const dbs = new JsonDatabase({
    databasePath:"./datas.json"
  });

module.exports = {
    // Config Not Editable
    "secretKey": "SECRET",
    "token": "TOKEN",
    "owner": "OWNER",
    db: dbs,

    // Config Editable
    "addbotchannel": "Bot Ekleme Kanal ID",
    "logchannel": "Bot Log Kanal ID",
    "adminchannel": "Bot Onaylama Kanal ID",
    "adminrole": "Bot Admin Rolu",



    "footer": "Alt Kisim",

}