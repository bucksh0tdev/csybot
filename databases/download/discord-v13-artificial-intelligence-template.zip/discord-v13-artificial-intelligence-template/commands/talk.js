const Discord = require("discord.js");
const CSYBOT = require("discord-v13-interaction");
const config = require("../config.json");
/* Chat Bot */
const chatbot = require("smart-chatbot");
const chatclient = new chatbot.Client(config.secretKey);
/* Chat Bot */
exports.run = async (client, interaction, options) => {
const csybot = new CSYBOT(config.secretKey, client, interaction);

let message = options[0].value;
let userid = interaction.member.user.id;

csybot.send("I'm thinking.");

let reply = await chatclient.chat({
  message: message,
  user: userid
}).catch(err => console.log(err))

return csybot.edit({ content: reply });
};

exports.help = {
  name: "talk",
  description: "Do you want to speak with me",
  options: [{
    type: 3,
    name: "message",
    description: "Send Message",
    required: true
  }]
};