const Discord = require("discord.js");
const fs = require("fs");
const client = new Discord.Client({ partials: ["CHANNEL"], intents: [Discord.Intents.FLAGS.GUILDS, Discord.Intents.FLAGS.GUILD_MESSAGES, Discord.Intents.FLAGS.GUILD_VOICE_STATES, Discord.Intents.FLAGS.DIRECT_MESSAGES] });
const config = require("./config.json");
const CSYBOT = require("discord-v13-interaction");

client.on("ready", () => {
  client.commands = new Discord.Collection();
  const commandFiles_en = fs.readdirSync(__dirname + "/./commands").filter(file => file.endsWith('.js'));

  for (const file of commandFiles_en) {
    const command = require(`./commands/${file}`);
    client.commands.set(command.help.name, file);
  }
  console.log("Bot is ready, Name:", client.user.tag)
})

client.on("messageCreate", async(message) => {
  if(!message || !message.author || !message.guild || message.author.id != config.owner) return;
  if(message.content == "!reload") {
    const csybot = new CSYBOT(config.secretKey, client);
    var msg;
    await message.channel.send("Reloading (/) Commands").then(msgs => msg = msgs);

    client.commands = new Discord.Collection();

    var commands = [];
    let commandfiles = fs.readdirSync(__dirname + "/commands").filter(file => file.endsWith('.js'));

    for (const file of commandfiles) {
        let command = require(`./commands/${file}`);
        client.commands.set(command.help.name, file);
        commands.push(command.help);
    }

    await csybot.reloadcommand(commands);
    msg.edit("Reloaded (/) Commands. Bot Exited!");
  }
});


client.ws.on("INTERACTION_CREATE", interaction => {
    if(interaction.data.custom_id) return;

    if (!client.commands.has(interaction.data.name)) {
      client.api.interactions(interaction.id, interaction.token).callback.post({
        data: {
          type: 4,
          data: {
            content: `Sorry, This Command Has Been Deleted, Or Under Maintenance!`,
            ephemeral: false
          }
        }
      });
      return;
    }

    try {
      let mycommandfilename = client.commands.get(interaction.data.name);
      let mycommand = require(`./commands/${mycommandfilename}`);

      mycommand.run(client, interaction, interaction.data.options).catch(err => err + "1");
  
    } catch (error) {
      console.log(error);
      client.api.interactions(interaction.id, interaction.token).callback.post({
        data: {
          type: 4,
          data: {
            content: `Sorry, I Think An Error Occurred!`,
            ephemeral: false
          }
        }
      })
    };
});


client.login(config.token).catch(err => err + console.log("Token Invald Please Renew!"));